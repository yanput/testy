package org.example.mtgtests.client.utils;

final class BodyParsingException extends RuntimeException {
    public BodyParsingException(Throwable cause) {
        super(cause);
    }
}
