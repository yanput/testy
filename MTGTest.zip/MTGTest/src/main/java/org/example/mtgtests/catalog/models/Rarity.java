package org.example.mtgtests.catalog.models;

public enum Rarity {
    COMMON, UNCOMMON, RARE, MYTHIC_RARE
}
