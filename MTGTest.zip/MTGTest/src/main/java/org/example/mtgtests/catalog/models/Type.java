package org.example.mtgtests.catalog.models;

public enum Type {
    LAND, CREATURE, ENCHANTMENT, INSTANT, SORCERY
}
